CREATE VIEW GV_$GC_ELEMENTS_W_COLLISIONS AS select "INST_ID","GC_ELEMENT_ADDR","CON_ID" from gv$gc_elements_with_collisions
/
