CREATE VIEW V_$QUEUEING_MTH AS select "NAME","CON_ID" from v$queueing_mth
/
