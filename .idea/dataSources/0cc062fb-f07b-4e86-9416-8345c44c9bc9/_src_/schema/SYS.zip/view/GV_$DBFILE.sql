CREATE VIEW GV_$DBFILE AS select "INST_ID","FILE#","NAME","CON_ID" from gv$dbfile
/
