CREATE VIEW GV_$AW_ALLOCATE_OP AS select "INST_ID","NAME","LONGNAME","CON_ID" from gv$aw_allocate_op
/
