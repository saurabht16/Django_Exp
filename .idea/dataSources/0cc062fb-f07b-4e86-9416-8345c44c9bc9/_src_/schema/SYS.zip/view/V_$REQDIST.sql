CREATE VIEW V_$REQDIST AS select "BUCKET","COUNT","CON_ID" from v$reqdist
/
