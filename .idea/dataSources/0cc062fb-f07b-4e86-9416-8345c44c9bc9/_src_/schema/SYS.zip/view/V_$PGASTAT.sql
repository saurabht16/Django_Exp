CREATE VIEW V_$PGASTAT AS select "NAME","VALUE","UNIT","CON_ID" from v$pgastat
/
