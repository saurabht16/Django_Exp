CREATE VIEW GV_$PGASTAT AS select "INST_ID","NAME","VALUE","UNIT","CON_ID" from gv$pgastat
/
