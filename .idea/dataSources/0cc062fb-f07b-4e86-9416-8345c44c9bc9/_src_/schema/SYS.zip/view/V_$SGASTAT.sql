CREATE VIEW V_$SGASTAT AS select "POOL","NAME","BYTES","CON_ID" from v$sgastat
/
