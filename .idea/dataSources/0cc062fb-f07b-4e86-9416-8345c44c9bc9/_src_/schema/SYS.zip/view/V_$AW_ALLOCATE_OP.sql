CREATE VIEW V_$AW_ALLOCATE_OP AS select "NAME","LONGNAME","CON_ID" from v$aw_allocate_op
/
