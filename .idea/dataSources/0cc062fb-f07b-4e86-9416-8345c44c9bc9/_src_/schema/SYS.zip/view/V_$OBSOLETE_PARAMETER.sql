CREATE VIEW V_$OBSOLETE_PARAMETER AS select "NAME","ISSPECIFIED","CON_ID" from v$obsolete_parameter
/
