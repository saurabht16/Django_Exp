CREATE VIEW V_$TIMEZONE_NAMES AS select "TZNAME","TZABBREV","CON_ID" from v$timezone_names
/
