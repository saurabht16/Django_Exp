CREATE VIEW V_$TIMER AS select "HSECS","CON_ID" from v$timer
/
