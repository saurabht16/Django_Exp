CREATE VIEW GV_$DLM_MISC AS select "INST_ID","STATISTIC#","NAME","VALUE","CON_ID" from gv$dlm_misc
/
