CREATE VIEW V_$DBFILE AS select "FILE#","NAME","CON_ID" from v$dbfile
/
