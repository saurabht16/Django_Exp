CREATE VIEW GV_$ACCESS AS select "INST_ID","SID","OWNER","OBJECT","TYPE","CON_ID" from gv$access
/
