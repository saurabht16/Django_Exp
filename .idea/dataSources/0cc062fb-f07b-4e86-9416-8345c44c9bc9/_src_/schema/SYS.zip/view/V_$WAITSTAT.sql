CREATE VIEW V_$WAITSTAT AS select "CLASS","COUNT","TIME","CON_ID" from v$waitstat
/
