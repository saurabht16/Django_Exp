CREATE VIEW V_$SQLFN_ARG_METADATA AS select "FUNC_ID","ARGNUM","DATATYPE","DESCR","CON_ID" from v$sqlfn_arg_metadata
/
