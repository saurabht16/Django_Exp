CREATE VIEW V_$VERSION AS select "BANNER","CON_ID" from v$version
/
