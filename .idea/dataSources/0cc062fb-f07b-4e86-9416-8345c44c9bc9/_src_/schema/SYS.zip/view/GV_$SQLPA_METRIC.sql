CREATE VIEW GV_$SQLPA_METRIC AS select "INST_ID","METRIC_NAME","CON_ID" from gv$sqlpa_metric
/
