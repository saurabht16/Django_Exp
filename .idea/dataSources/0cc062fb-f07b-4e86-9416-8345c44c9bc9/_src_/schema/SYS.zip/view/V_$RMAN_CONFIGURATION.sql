CREATE VIEW V_$RMAN_CONFIGURATION AS select "CONF#","NAME","VALUE","CON_ID" from v$rman_configuration
/
