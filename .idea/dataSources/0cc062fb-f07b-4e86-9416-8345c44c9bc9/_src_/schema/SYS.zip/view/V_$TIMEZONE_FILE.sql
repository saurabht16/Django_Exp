CREATE VIEW V_$TIMEZONE_FILE AS select "FILENAME","VERSION","CON_ID" from v$timezone_file
/
