CREATE VIEW GV_$MYSTAT AS select "INST_ID","SID","STATISTIC#","VALUE","CON_ID" from gv$mystat
/
