CREATE VIEW V_$SYSTEM_CURSOR_CACHE AS select "OPENS","HITS","HIT_RATIO","CON_ID" from v$system_cursor_cache
/
