CREATE VIEW V_$SEGSTAT_NAME AS select "STATISTIC#","NAME","SAMPLED","CON_ID" from v$segstat_name
/
