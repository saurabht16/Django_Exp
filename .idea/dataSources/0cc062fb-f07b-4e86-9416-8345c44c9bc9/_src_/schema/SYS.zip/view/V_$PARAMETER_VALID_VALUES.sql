CREATE VIEW V_$PARAMETER_VALID_VALUES AS select "NUM","NAME","ORDINAL","VALUE","ISDEFAULT","CON_ID" from v$parameter_valid_values
/
