CREATE VIEW V_$SESSION_CURSOR_CACHE AS select "MAXIMUM","COUNT","OPENS","HITS","HIT_RATIO","CON_ID" from v$session_cursor_cache
/
